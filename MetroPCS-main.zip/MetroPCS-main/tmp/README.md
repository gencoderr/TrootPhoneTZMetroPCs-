# MetroPCS
Availability and estimated shipping dates of cell-phones sold by MetroPCS online.
## Storage
<!-- TABLE_START --><!-- TABLE_END -->
## Tested Environment
✔ Ubuntu 22.04

✔ Windows 11 22H2

✔ macOS 13.5
## Installation
```
git clone https://github.com/dsccccc/MetroPCS.git
cd ./MetroPCS
pip install -r requirements.txt
```
